
#include <iostream>
#include <list>
#include "ParInt.hh"
#include "LlistaIOParInt.hh"

using namespace std;



int main() {
    list<ParInt> aa;
    LlegirLlistaParInt(aa);
    EscriureLlistaParInt(aa); 
    

}
